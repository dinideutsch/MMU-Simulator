package com.hit.service;

import com.hit.dm.DataModel;

public class CacheUnitController<T> extends java.lang.Object {
    private CacheUnitService<T> cacheUnitService;
    public CacheUnitController(){
         cacheUnitService=new CacheUnitService<T>();
    }
    public boolean update(DataModel<T>[] dataModels){
        System.out.println(dataModels[0].toString());
        return  cacheUnitService.update(dataModels);
    }
    public boolean delete(DataModel<T>[] dataModels){
        System.out.println(dataModels[0].toString());
        return cacheUnitService.delete(dataModels);
    }
    public DataModel<T>[] get(DataModel<T>[] dataModels){
        System.out.println(dataModels[0].toString());
        return cacheUnitService.get(dataModels);
    }
    public void  shutdown(){
        cacheUnitService.shutdown();
    }
}
