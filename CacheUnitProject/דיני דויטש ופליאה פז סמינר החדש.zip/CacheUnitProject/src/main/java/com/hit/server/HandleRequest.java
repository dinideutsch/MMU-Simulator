package com.hit.server;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hit.dm.DataModel;
import com.hit.service.CacheUnitController;

import java.io.*;
import java.lang.reflect.Type;
import java.net.Socket;
import java.util.Map;
import java.util.Scanner;

public class HandleRequest<T> extends java.lang.Object implements java.lang.Runnable {
    private Socket socket;
    private CacheUnitController<T> controller;
    private  Request<DataModel<T>[]> request=null;
    public HandleRequest(Socket s, CacheUnitController<T> controller){
          this.socket=s;
          this.controller=controller;
    }
    @Override
    public void run() {
        getRequest();

        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        headerTypeHandler();
        //request.getBody();
    }
    private void  getRequest(){
        try {
            Scanner reader = new Scanner(new InputStreamReader(socket.getInputStream()));
//            T line;
//            line=(T) reader.readUTF();
            Type ref = new TypeToken<Request<DataModel<T>[]>>() {
            }.getType();
            this.request = new Gson().fromJson(String.valueOf(reader), ref);
           // ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void headerTypeHandler(){
        Map<String, String> headerType=request.getHeaders();
        switch (headerType.get("action")) {
            case "UPDATE":
               controller.update(request.getBody());
                break;
            case "GET":
                controller.get(request.getBody());
            case "DELETE":
                controller.delete(request.getBody());
                break;
            default:
                System.out.println("wrong action");
        }
    }
}
