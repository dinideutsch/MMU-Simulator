package com.hit.server;

public class Request<T> extends java.lang.Object implements java.io.Serializable {

    private java.util.Map<java.lang.String,java.lang.String> headers=null;
    private T body;
    public Request(java.util.Map<java.lang.String,java.lang.String> headers, T body){
          this.headers=headers;
          this.body=body;
    }
    public java.util.Map<java.lang.String,java.lang.String> getHeaders(){
        return  this.headers;
    }
    public void setHeaders(java.util.Map<java.lang.String,java.lang.String> headers){
        this.headers=headers;
    }
    public T getBody(){
        return body;
    }
    public void setBody(T body){
        this.body=body;
    }
    @Override
    public String toString() {
        return "Request{" +
                "headers=" + headers +
                ", body=" + body +
                '}';
    }
}
