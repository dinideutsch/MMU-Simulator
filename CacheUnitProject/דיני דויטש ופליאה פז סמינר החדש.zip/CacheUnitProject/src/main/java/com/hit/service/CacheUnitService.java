package com.hit.service;

import com.hit.algorithm.IAlgoCache;
import com.hit.algorithm.LRUAlgoCacheImpl;
import com.hit.dao.DaoFileImpl;
import com.hit.dm.DataModel;
import com.hit.memory.CacheUnit;

public class CacheUnitService<T> extends java.lang.Object{
    private final Integer capacity=3;
    private CacheUnit<T> cacheUnit;
    private DaoFileImpl<T> hardDisk;
    private IAlgoCache<Long,DataModel<T>> algorithm;
    public CacheUnitService(){
        this.hardDisk=new DaoFileImpl<T>("datasource.txt");
        this.algorithm=new LRUAlgoCacheImpl<>(capacity);
        cacheUnit=new CacheUnit<>(algorithm);
    }
    public boolean update(DataModel<T>[] dataModels){
        try {
            if(dataModels!=null) {
                // cacheUnit.removeDataModels();
                cacheUnit.putDataModels(dataModels);
            }
            return true;
        }
        catch (Exception e){
            return false;
        }


    }
    public boolean delete(DataModel<T>[] dataModels){
        Long[] dataModelsId=new Long[dataModels.length];
        int index=0;
        try {
            for (DataModel<T> data : dataModels) {
                dataModelsId[index] = data.getDataModelId();
                index++;
            }
            cacheUnit.removeDataModels(dataModelsId);
            return true;
        }
        catch (Exception e) {
            return  false;
        }
    }
    public DataModel<T>[] get(DataModel<T>[] dataModels){
        Long[] dataModelsId=new Long[dataModels.length];
        int index=0;
        for(DataModel<T> data:dataModels){
            dataModelsId[index]=data.getDataModelId();
            index++;
        }
        dataModels=cacheUnit.getDataModels(dataModelsId);
        return dataModels;
    }
    public void shutdown(){
        DataModel<T>[] cacheData=cacheUnit.getAll();
        for(DataModel<T> data:cacheData){
            hardDisk.save(data);
        }
    }
}
