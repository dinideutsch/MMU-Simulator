package com.hit.server;

import com.hit.service.CacheUnitController;

import java.beans.PropertyChangeEvent;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server extends java.lang.Object implements java.beans.PropertyChangeListener, java.lang.Runnable {
    private static String command="";//static?
//    private static boolean serverUp = true;
    private  CacheUnitController<String> controller=null;
    private ServerSocket server = null;
    static ExecutorService executor =  Executors.newCachedThreadPool();
    public Server() throws IOException {
        this.server = new ServerSocket(12345);
        this.controller=new CacheUnitController<String>();
    }

    @Override
    public void run() {
//        handleServerShutdown();
        try {
            while (!(command.equals("Shutdown"))) {
                Socket someClient = server.accept();
                executor.execute(new HandleRequest<String>(someClient, this.controller));
            }
            shutdown();
            System.out.println("Server close");
        } catch (Exception e) {
            System.out.println("tired of waiting for connection");
        }
    }

    private void shutdown(){
        controller.shutdown();
        try {
            server.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        this.command = ((String) evt.getPropertyName());
    }

}
