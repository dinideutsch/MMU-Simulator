package com.hit;
import com.hit.algorithm.LRUAlgoCacheImpl;
import com.hit.dm.DataModel;
import com.hit.memory.CacheUnit;
import com.hit.server.Server;
import com.hit.util.CLI;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class serverTest {
//    @Test
//    public void main(String[] args) throws IOException {
//        serverTest() ;
//    }
   // @Test
    public static void main(String[] args) throws IOException {
        CLI cli = new CLI(System.in, System.out);
        Server server = new Server();
        cli.addPropertyChangeListener(server);
        new Thread(cli).start();
    }

   // public void serverTest() throws IOException {
//        ObjectOutputStream output = new ObjectOutputStream(System.out);
//        ObjectInputStream input = new ObjectInputStream(System.in);
//        CLI cli=new CLI(input,output);
//
//        System.out.println("Starting server");
//
//        try {
//            Server server = new Server();
////            new Thread(server).start();
//           // Executor executor  = Executors.newSingleThreadExecutor(3);
//            Executor executor = Executors.newFixedThreadPool(3);
//            executor.execute(cli);
//            executor.execute(server);
//            ((ExecutorService) executor).shutdown();
//
//        } catch (Exception e) {
//            System.out.println("tiered of waiting for connection");
//        }
        //CLI cli = new CLI(System.in, System.out);

       // Server server = new Server();
       //= ExecutorService executor  Executors.newFixedThreadPool(3);
       // executor.execute(cli);
      // cli.run();
       // server.run();
        //cli.addPropertyChangeListener(server);
       // executor.execute(server);

//        new Thread(cli).start();

  //  }
}
