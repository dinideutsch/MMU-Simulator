package com.hit.util;

import java.beans.PropertyChangeSupport;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class CLI  implements java.lang.Runnable {
    private PropertyChangeSupport support;
//    private  List<Server> observers = new ArrayList<>();
    private java.io.InputStream in;
    private java.io.OutputStream out;
    private OutputStreamWriter writer;
    public static final java.lang.String START="Start";
    public static final java.lang.String SHUTDOWN="Shutdown";
    private String command=null;
  // private OutputStreamWriter wr;
    public CLI(java.io.InputStream in, java.io.OutputStream out){
        this.in=in;
        this.out= out;
        support = new PropertyChangeSupport(this);
    }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener pcl){
        support.addPropertyChangeListener(pcl);
    }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener pcl){
        support.removePropertyChangeListener(pcl);
    }
    public void write(java.lang.String string){
        this.writer = new OutputStreamWriter(this.out);
        try {
            writer.write(string + '\n');
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (true){
            String oldCommand=this.command;
            readCommandFromCommandLine();
            if (command.equals("Start")){
                support.firePropertyChange("command", oldCommand, command);

            }
           else if(command.equals("Shutdown")){
                support.firePropertyChange("command", oldCommand, command);
                shutdown(this.writer);
                break;
            }
            else{
                System.out.println("Not a valid command\n");
            }
        }

    }
    private void readCommandFromCommandLine(){
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        write("Please enter your command\n");

        String newCommand = null;
        try {
            newCommand  = bufferedReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.command=newCommand;
    }
    private void shutdown(OutputStreamWriter writer){
        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Shutdown server\n");
    }
}
