package com.hit.server;

import com.hit.algorithm.LRUAlgoCacheImpl;
import com.hit.dm.DataModel;
import com.hit.memory.CacheUnit;
import org.junit.Assert;
import org.junit.Test;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class clientTest {
    @Test
    public static void main(String[] args) {
        startClient();
    }

    private static void startClient() {
        try {
            InetAddress localaddr = InetAddress.getLocalHost();
            Socket myServer = new Socket(localaddr.getHostAddress(), 12345);
            ObjectOutputStream output = new ObjectOutputStream(myServer.getOutputStream());
          //  ObjectInputStream input = new ObjectInputStream(myServer.getInputStream());
            Map<String,String> headers=new HashMap<>();
            headers.put("action","UPDATE");
            DataModel<String>[] dataModelsArray=new DataModel[4];
            dataModelsArray[0]= new DataModel<String>(1L,"data1");
            dataModelsArray[1]= new DataModel<String>(2L,"data2");
            Request<DataModel<String>> req = new Request(headers,dataModelsArray);
//            Process socket;
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(myServer.getOutputStream()));
            output.writeObject(req);
            output.flush();

         //   final Object o = input.readObject();
          //  System.out.println("Got from server:" + o);
            output.close();
           // input.close();
            myServer.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
